export interface Employee {
  name: string;
  address: string;
  mobile: string;
  salary: number;
  bloodGroup: string;
}